﻿-- Set the database context (if needed)
USE RetailStoreDB;

-- Create the Products table
CREATE TABLE dbo.Products (
    ProductID INT PRIMARY KEY IDENTITY(1,1),
    Name VARCHAR(100) NOT NULL,
    Price DECIMAL(10,2) NOT NULL,
    Quantity INT NOT NULL
);

-- Insert sample data into the Products table
INSERT INTO dbo.Products (Name, Price, Quantity) VALUES
('Pencil', 0.75, 100),
('Notebook', 2.50, 50),
('Eraser', 0.50, 150),
('Ruler', 1.20, 80),
('Backpack', 15.00, 20),
('Pen', 1.00, 120),
('Highlighter', 1.50, 60),
('Calculator', 10.00, 30),
('Colored Pencils', 3.00, 40),
('Construction Paper', 4.00, 25);

-- Retrieve the top 1000 products
SELECT TOP (1000) ProductID, Name, Price, Quantity
FROM dbo.Products;
