﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BridgetNarte_FinalExam
{
    public partial class Form1 : Form
    {
        Product productModel = new Product();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            using (RetailStoreDBEntities1 db = new RetailStoreDBEntities1())
            {
                productModel = new Product
                {
                    Name = txtName.Text,
                    Price = Convert.ToDecimal(txtPrice.Text),
                    Quantity = Convert.ToInt32(txtQuantity.Text)
                };

                db.Products.Add(productModel);
                db.SaveChanges();
            }

            MessageBox.Show("Data Added Successfully!");
            ClearInputs();
            populatedDataGridView();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            populatedDataGridView();
        }

        private void populatedDataGridView()
        {
            RetailStoreDBEntities1 db = new RetailStoreDBEntities1();
            dataGridView1.DataSource = db.Products.ToList<Product>();
            dataGridView1.ReadOnly = true;

        }

        private void btnClearAll_Click(object sender, EventArgs e)
        {
            ClearInputs();

        }
        private void ClearInputs()
        {
            txtName.Text = "";
            txtPrice.Text = "";
            txtQuantity.Text = "";
            productModel.ProductID = 0;
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow.Index != -1)
            {
                productModel.ProductID = (int)dataGridView1.CurrentRow.Cells["ProductID"].Value;
                RetailStoreDBEntities1 db = new RetailStoreDBEntities1();
                productModel = db.Products.Where(x => x.ProductID == productModel.ProductID).FirstOrDefault();
                txtName.Text = productModel.Name;
                txtPrice.Text = productModel.Price.ToString();
                txtQuantity.Text = productModel.Quantity.ToString();

            }

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            using (RetailStoreDBEntities1 db = new RetailStoreDBEntities1())
            {
                var productInDb = db.Products.Find(productModel.ProductID);
                if (productInDb != null)
                {
                    productInDb.Name = txtName.Text;
                    productInDb.Price = Convert.ToDecimal(txtPrice.Text);
                    productInDb.Quantity = Convert.ToInt32(txtQuantity.Text);
                    db.SaveChanges();
                }
            }

            MessageBox.Show("Data Updated Successfully!");
            ClearInputs();
            populatedDataGridView();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (productModel.ProductID != 0)
            {
                using (RetailStoreDBEntities1 db = new RetailStoreDBEntities1())
                {
                    var productToDelete = db.Products.Find(productModel.ProductID);
                    if (productToDelete != null)
                    {
                        db.Products.Remove(productToDelete);
                        db.SaveChanges();
                    }
                }

                MessageBox.Show("Data Deleted Successfully!");
                ClearInputs();
                populatedDataGridView();
            }
            else
            {
                MessageBox.Show("Please select the record you want to delete.");
            }
        }
    }


}
